<?php

/**
 * @file
 * Coder hook function api documentation.
 */

// @TODO : document hook_reviews()
function hook_reviews() {
}
